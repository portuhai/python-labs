class VehicleDTO:
    """
    Об'єкт передачі даних для техніки (Vehicle).
    """
    def __init__(self, vehicle_id, type, license_plate, quarry_name=None):
        self.vehicle_id = vehicle_id
        self.type = type
        self.license_plate = license_plate
        self.quarry_name = quarry_name

    def to_dict(self):
        """ Перетворення об'єкта DTO у словник для JSON-відповіді. """
        data = {
            'vehicle_id': self.vehicle_id,
            'type': self.type,
            'license_plate': self.license_plate
        }
        if self.quarry_name:
            data['quarry_name'] = self.quarry_name
        return data