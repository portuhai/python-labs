from app.dao.shift_dao import ShiftDAO
from app.dtos.shift_dto import ShiftDTO


class ShiftService:
    """
    Сервіс для роботи зі Змінами (Shifts).
    """

    def __init__(self):
        self.shift_dao = ShiftDAO()

    def get_today_shifts_details(self):
        """
        Отримати детальний список змін за сьогодні.
        """
        raw_shifts = self.shift_dao.get_shifts_today_with_details()

        shift_dtos = []
        for shift in raw_shifts:
            dto = ShiftDTO(
                shift_id=shift['shift_id'],
                shift_date=shift['shift_date'],
                driver_name=shift['driver_name'],
                vehicle_plate=shift['vehicle_plate']
            )
            shift_dtos.append(dto.to_dict())

        return shift_dtos