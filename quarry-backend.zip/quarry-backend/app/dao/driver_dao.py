from app import mysql


class DriverDAO:
    """
    DAO (Data Access Object) для таблиці Drivers.
    Відповідає виключно за виконання SQL-запитів.
    """

    def get_drivers_medical_ok_today(self):
        """ Завдання 1: Водії з успішним медоглядом та сьогоднішньою зміною. """

        query = """
        SELECT d.driver_id, d.full_name, mc.result
        FROM Drivers d
        JOIN Shifts s ON d.driver_id = s.driver_id
        JOIN MedicalChecks mc ON d.driver_id = mc.driver_id
        WHERE s.shift_date = CURDATE()
          AND mc.check_date = CURDATE()
          AND mc.result = 'OK'
        GROUP BY d.driver_id, d.full_name, mc.result;
        """

        cur = mysql.connection.cursor()
        cur.execute(query)

        data = cur.fetchall()
        cur.close()

        return data

    def create_driver(self, data):
        """ Вставка даних у таблицю Drivers. """
        query = """
        INSERT INTO Drivers (quarry_id, full_name, license_number) 
        VALUES (%s, %s, %s)
        """
        cur = mysql.connection.cursor()
        cur.execute(query, (data['quarry_id'], data['full_name'], data['license_number']))
        mysql.connection.commit()
        driver_id = cur.lastrowid  # Отримати ID щойно створеного запису
        cur.close()
        return driver_id

    def update_driver(self, driver_id, data):
        """ Оновлення даних у таблиці Drivers. """
        # Тут ми оновлюємо лише повне ім'я та приписку до кар'єру
        query = """
        UPDATE Drivers SET full_name = %s, quarry_id = %s 
        WHERE driver_id = %s
        """
        cur = mysql.connection.cursor()
        cur.execute(query, (data['full_name'], data['quarry_id'], driver_id))
        mysql.connection.commit()
        cur.close()
        return cur.rowcount  # Повертає кількість оновлених рядків

    def delete_driver(self, driver_id):
        """ Видалення даних з таблиці Drivers. """
        query = "DELETE FROM Drivers WHERE driver_id = %s"
        cur = mysql.connection.cursor()
        cur.execute(query, (driver_id,))
        mysql.connection.commit()
        cur.close()
        return cur.rowcount