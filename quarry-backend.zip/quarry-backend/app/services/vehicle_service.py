from app.dao.vehicle_dao import VehicleDAO
from app.dtos.vehicle_dto import VehicleDTO


class VehicleService:
    """
    Сервіс для роботи з технікою (Vehicles).
    """

    def __init__(self):
        self.vehicle_dao = VehicleDAO()

    def get_vehicles_by_quarry(self, quarry_id):
        """
        Отримати список техніки, приписаної до певного кар'єру.
        """
        # 1. Отримати сирі дані з бази через DAO
        raw_vehicles = self.vehicle_dao.get_vehicles_by_quarry(quarry_id)

        # 2. Перетворити сирі дані у список DTO-об'єктів
        vehicle_dtos = []
        for vehicle in raw_vehicles:
            dto = VehicleDTO(
                vehicle_id=vehicle['vehicle_id'],
                type=vehicle['type'],
                license_plate=vehicle['license_plate'],
                quarry_name=vehicle['quarry_name']
            )
            # Додаємо DTO у вигляді словника для JSON-відповіді
            vehicle_dtos.append(dto.to_dict())

        return vehicle_dtos