from app import mysql


class VehicleDAO:
    """
    DAO для таблиці Vehicles.
    """

    def get_vehicles_by_quarry(self, quarry_id):
        """
        Виводить усю техніку (Vehicles), приписану до певного кар'єру (Quarries).
        (Зв'язок Багато до Одного: Vehicles (M) -> Quarries (1))
        """
        query = """
        SELECT 
            v.vehicle_id, 
            v.type, 
            v.license_plate, 
            q.name AS quarry_name
        FROM Vehicles v
        JOIN Quarries q ON v.quarry_id = q.quarry_id
        WHERE v.quarry_id = %s;
        """
        cur = mysql.connection.cursor()
        cur.execute(query, (quarry_id,))
        data = cur.fetchall()
        cur.close()
        return data