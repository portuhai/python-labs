from flask import Flask
from config import Config
from app import mysql
from app.controllers.driver_controller import driver_bp
from app.controllers.vehicle_controller import vehicle_bp
from app.controllers.shift_controller import shift_bp

app = Flask(__name__)
app.config.from_object(Config)
mysql.init_app(app)
app.register_blueprint(driver_bp)
app.register_blueprint(vehicle_bp)
app.register_blueprint(shift_bp)

if __name__ == '__main__':
    app.run(debug=True)