from app.dao.driver_dao import DriverDAO
from app.dtos.driver_dto import DriverDTO


class DriverService:
    """
    Сервіс для роботи з водіями. Містить бізнес-логіку.
    """

    def __init__(self):
        self.driver_dao = DriverDAO()

    def get_medical_ok_drivers(self):
        """
        Завдання 1: Отримати список водіїв, що пройшли медогляд ОК сьогодні.
        Бізнес-логіка: тут ми просто передаємо дані.
        """
        raw_drivers = self.driver_dao.get_drivers_medical_ok_today()

        driver_dtos = []
        for driver in raw_drivers:
            dto = DriverDTO(
                driver_id=driver['driver_id'],
                full_name=driver['full_name'],
                check_result=driver['result']
            )
            driver_dtos.append(dto.to_dict())

        return driver_dtos

    def create_driver(self, data):
        return self.driver_dao.create_driver(data)

    def update_driver(self, driver_id, data):
        return self.driver_dao.update_driver(driver_id, data)

    def delete_driver(self, driver_id):
        return self.driver_dao.delete_driver(driver_id)