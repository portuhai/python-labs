class Config:
    DEBUG = True
    SECRET_KEY = 'твоя_дуже_складна_і_секретна_фраза'

    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = 'AlInA20112007'
    MYSQL_DB = 'quarry_db'
    MYSQL_CURSORCLASS = 'DictCursor'