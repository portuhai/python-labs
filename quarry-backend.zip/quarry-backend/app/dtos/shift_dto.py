class ShiftDTO:
    """
    Об'єкт передачі даних для Зміни (Shift).
    Використовується для відображення зв'язку M:M.
    """
    def __init__(self, shift_id, shift_date, driver_name, vehicle_plate):
        self.shift_id = shift_id
        self.shift_date = shift_date.strftime('%Y-%m-%d') # Форматуємо дату
        self.driver_name = driver_name
        self.vehicle_plate = vehicle_plate

    def to_dict(self):
        """ Перетворення об'єкта DTO у словник для JSON-відповіді. """
        return {
            'shift_id': self.shift_id,
            'shift_date': self.shift_date,
            'driver_name': self.driver_name,
            'vehicle_license_plate': self.vehicle_plate
        }