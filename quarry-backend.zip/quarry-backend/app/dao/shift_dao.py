from app import mysql


class ShiftDAO:
    """
    DAO для таблиці Shifts.
    """

    def get_shifts_today_with_details(self):
        """
        Завдання M:M: Виводить усі сьогоднішні зміни із зазначенням
        водія (Drivers) та техніки (Vehicles), які були задіяні.
        """
        query = """
        SELECT 
            s.shift_id,
            s.shift_date,
            d.full_name AS driver_name,
            v.license_plate AS vehicle_plate
        FROM Shifts s
        JOIN Drivers d ON s.driver_id = d.driver_id
        JOIN Vehicles v ON s.vehicle_id = v.vehicle_id
        WHERE s.shift_date = CURDATE();
        """
        cur = mysql.connection.cursor()
        cur.execute(query)
        data = cur.fetchall()
        cur.close()
        return data