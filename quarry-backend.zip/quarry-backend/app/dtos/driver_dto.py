class DriverDTO:
    """
    Об'єкт передачі даних для водія.
    Використовується для формування чистої відповіді клієнту.
    """

    def __init__(self, driver_id, full_name, quarry_name=None, check_result=None):
        self.driver_id = driver_id
        self.full_name = full_name
        self.quarry_name = quarry_name
        self.check_result = check_result

    def to_dict(self):
        """ Перетворення об'єкта DTO у словник для JSON-відповіді. """
        data = {
            'driver_id': self.driver_id,
            'full_name': self.full_name
        }
        if self.quarry_name is not None:
            data['quarry_name'] = self.quarry_name
        if self.check_result is not None:
            data['medical_check_result'] = self.check_result

        return data