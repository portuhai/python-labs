from flask import Blueprint, jsonify, request
from app.services.driver_service import DriverService

driver_bp = Blueprint('drivers', __name__)
driver_service = DriverService()


@driver_bp.route('/api/drivers/medical-ok-today', methods=['GET'])
def get_drivers_medical_ok():
    """
    Обробляє GET-запит на /api/drivers/medical-ok-today.
    Повертає водіїв з успішним медоглядом, що керували сьогодні.
    """
    try:
        result_dtos = driver_service.get_medical_ok_drivers()
        return jsonify({
            "status": "success",
            "count": len(result_dtos),
            "data": result_dtos
        }), 200

    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@driver_bp.route('/api/drivers', methods=['POST'])
def create_driver():
    data = request.get_json()

    if not data:
        return jsonify({"status": "error", "message": "Недійсний формат JSON або порожні дані"}), 400

    required_fields = ['quarry_id', 'full_name', 'license_number']
    if not all(field in data for field in required_fields):
        return jsonify({
            "status": "error",
            "message": f"Відсутні обов'язкові поля: {', '.join(required_fields)}"
        }), 400

    try:
        new_id = driver_service.create_driver(data)
        return jsonify({
            "status": "success",
            "id": new_id,
            "message": "Водій успішно доданий"
        }), 201

    except Exception as e:
        print(f"Помилка бази даних при створенні водія: {e}")
        return jsonify({"status": "error", "message": f"Помилка сервера: {e}"}), 500


@driver_bp.route('/api/drivers/<int:driver_id>', methods=['PUT'])
def update_driver(driver_id):
    data = request.get_json()
    rows_affected = driver_service.update_driver(driver_id, data)

    if rows_affected > 0:
        return jsonify({"status": "success", "message": "Водій успішно оновлений"}), 200

    return jsonify({"status": "error", "message": "Водія з таким ID не знайдено"}), 404


@driver_bp.route('/api/drivers/<int:driver_id>', methods=['DELETE'])
def delete_driver(driver_id):
    rows_affected = driver_service.delete_driver(driver_id)

    if rows_affected > 0:
        return jsonify({"status": "success", "message": "Водій успішно видалений"}), 200

    return jsonify({"status": "error", "message": "Водія з таким ID не знайдено"}), 404
